# odin-landing-page
A landing page originally based on The Odin Project's guidelines to practice vanilla HTML &amp; CSS flexbox.
